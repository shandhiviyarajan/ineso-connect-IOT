import { Message } from "../../components/molecules/Toast";
import { httpInstance, httpUpload } from "../interceptors/interceptors";

export const PROFILE = {
};

let httpRequest;

//upload profile picture
//payload = {id, formData}
