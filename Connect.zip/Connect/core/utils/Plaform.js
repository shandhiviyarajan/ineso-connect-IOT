import { Platform } from "react-native"
export const isOS = () =>{
    return Platform.OS === 'ios'
};