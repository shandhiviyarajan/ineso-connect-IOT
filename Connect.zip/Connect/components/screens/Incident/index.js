import React from "react";
import { Text, View } from "react-native";

function IncidentReporting() {
  return (
    <View
      style={{
        flex: 1,
        padding: 12,
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <Text>Await for information</Text>
    </View>
  );
}

export default IncidentReporting;
