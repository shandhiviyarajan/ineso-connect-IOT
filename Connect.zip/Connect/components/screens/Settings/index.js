import React from "react";
import { View } from "react-native";
import { Text } from "react-native-paper";

const SettingsScreen = () => {
  return (
    <>
      <View
        style={{
          flex: 1,
        }}
      ></View>
    </>
  );
};

export default SettingsScreen;
