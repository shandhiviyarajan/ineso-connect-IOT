import axios from "axios";
import React from "react";
import {
  StatusBar,
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
} from "react-native";

export const HelloWorld = () => {
  const [user_list, setUserList] = React.useState(null);
  const [current_user, setCurrentUser] = React.useState(null);

  const getUsers = async () => {
    await axios.get("https://gorest.co.in/public/v2/users").then((response) => {
      setUserList(response.data);
    });
  };

  const onItemPress = (user) => {
    setCurrentUser(user);
  };

  React.useEffect(() => {
    getUsers();
  }, []);

  const UserInfo = ({ user }) => (
    <View style={styles.container_user}>
      <Text style={styles.name}>{user.name}</Text>
      <Text style={styles.gender}>{user.gender}</Text>
      <Text style={styles.email}>{user.email}</Text>
    </View>
  );

  return (
    <>
      <SafeAreaView>
        {user_list && (
          <>
            {current_user && <UserInfo user={current_user} />}

            <ScrollView>
              <View>
                {user_list.map((user) => (
                  <>
                    <TouchableOpacity onPress={() => onItemPress(user)}>
                      <View style={styles.container}>
                        <Text style={styles.name}>{user.name}</Text>
                        <Text style={styles.email}>{user.email}</Text>
                      </View>
                    </TouchableOpacity>
                  </>
                ))}
              </View>
            </ScrollView>
          </>
        )}
      </SafeAreaView>
    </>
  );
};
//stylesheet
const styles = StyleSheet.create({
  hello_world: {
    paddingTop: StatusBar.currentHeight,
  },

  container_user:{
    backgroundColor:"#d9d9d9",
    padding:24,
  },

  container: {
    padding: 24,
    borderWidth: 1,
    borderBottomColor: "#fff",
    borderColor: "#d8d8d8",
  },
  name: {
    fontSize: 24,
  },
  email: {
    fontSize: 16,
  },
});
