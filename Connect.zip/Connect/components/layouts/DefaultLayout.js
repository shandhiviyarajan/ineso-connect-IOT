import React from "react"

export const DefaultLayout = ({children}) =>{
    return (
        <>
        {children}
        </>
    )
}